"""Team Nova - time-aware SASRec challenger for Phase 2.

Trains a causal self-attention next-click model from the supplied historical feedback,
then ranks only items live at each prediction timestamp. Users without enough click
history fall back to a recency-smoothed CTR prior. This is an experimental challenger;
compare it to Darling v5/v6 with the team's chronological pooled-slate replay before use.

Dependencies: numpy, pandas, torch (preinstalled in the competition torch environment).
"""
import json
import os
from pathlib import Path

import numpy as np
import pandas as pd

MAX_SEQ_LEN = 50
D_MODEL = 64
N_HEADS = 2
N_LAYERS = 2
DROPOUT = 0.2
BATCH_SIZE = 256
EPOCHS = 5
LEARNING_RATE = 1e-3
TOP_K = 512
HALF_LIFE_DAYS = 3.0
CTR_PRIOR = 100.0
DAY = 86400.0
N_GAP_BUCKETS = 8
SIM_EXPOSURE = True
SKIP_REJECTED = True
SEED = 17


def read_any(data, name, **kw):
    """Read parquet when supported; fall back to the canonical CSV."""
    data = Path(data)
    pq, csv = data / (name + ".parquet"), data / (name + ".csv")
    if pq.exists():
        try:
            return pd.read_parquet(pq)
        except Exception as exc:
            print("parquet read failed for", name, exc)
    return pd.read_csv(csv, **kw)


def load_feedback(data):
    try:
        fb = read_any(data, "feedback_long", dtype={"event_id": str, "user_id": str, "itemID": str})
    except Exception as exc:
        print("feedback_long unavailable, reading feedback.jsonl:", exc)
        rows = []
        with open(Path(data) / "feedback.jsonl", encoding="utf-8") as f:
            for line in f:
                e = json.loads(line)
                for item in e["displayed_items"]:
                    rows.append((e["event_id"], e["user_id"], e["timestamp"], item,
                                 int(item == e.get("clicked_item"))))
        fb = pd.DataFrame(rows, columns=["event_id", "user_id", "timestamp", "itemID", "clicked"])
    fb = fb.astype({"event_id": str, "user_id": str, "itemID": str})
    fb["timestamp"] = fb["timestamp"].astype("int64")
    fb["clicked"] = fb["clicked"].astype("int8")
    return fb.drop_duplicates(["event_id", "itemID"])


def _gap_ids(times):
    """Bucket time since the previous click, with 0 reserved for the first token/padding."""
    times = np.asarray(times, dtype=np.int64)
    out = np.zeros(len(times), dtype=np.int64)
    if len(times) > 1:
        delta = np.maximum(np.diff(times), 0)
        edges = np.asarray([3600, 6 * 3600, DAY, 3 * DAY, 7 * DAY, 30 * DAY], dtype=float)
        out[1:] = np.digitize(delta, edges).astype(np.int64) + 1
    return out


def click_sequences(fb, item_to_idx):
    """Return each user's ordered clicked-item and inter-click-gap sequences."""
    pos = fb[fb["clicked"] == 1].sort_values(["user_id", "timestamp", "event_id"], kind="stable")
    result = {}
    for user, grp in pos.groupby("user_id", sort=False):
        ids = np.asarray([item_to_idx[x] for x in grp["itemID"].tolist() if x in item_to_idx], dtype=np.int64)
        ts = grp["timestamp"].to_numpy(dtype=np.int64)
        if len(ids):
            result[str(user)] = (ids, _gap_ids(ts))
    return result


def make_weighted_examples(fb, item_to_idx, max_seq_len):
    """Build SASRec next-click examples and modestly emphasize recent training targets."""
    pos = fb[fb["clicked"] == 1].sort_values(["user_id", "timestamp", "event_id"], kind="stable")
    latest_ts = int(pos["timestamp"].max()) if len(pos) else 0
    xs, gs, ys, ws = [], [], [], []
    for user, grp in pos.groupby("user_id", sort=False):
        ids = np.asarray([item_to_idx[x] for x in grp["itemID"].tolist() if x in item_to_idx], dtype=np.int64)
        ts = grp["timestamp"].to_numpy(dtype=np.int64)
        if len(ids) < 2:
            continue
        gaps = _gap_ids(ts)
        for target_pos in range(1, len(ids)):
            start = max(0, target_pos - max_seq_len)
            prefix = ids[start:target_pos]
            prefix_gaps = gaps[start:target_pos]
            x = np.zeros(max_seq_len, dtype=np.int64)
            g = np.zeros(max_seq_len, dtype=np.int64)
            n = len(prefix)
            x[:n] = prefix
            g[:n] = prefix_gaps
            xs.append(x)
            gs.append(g)
            ys.append(ids[target_pos])
            age_days = max(0.0, (latest_ts - float(ts[target_pos])) / DAY)
            ws.append(0.5 ** (age_days / HALF_LIFE_DAYS))
    if not xs:
        return (np.zeros((0, max_seq_len), dtype=np.int64),
                np.zeros((0, max_seq_len), dtype=np.int64),
                np.zeros(0, dtype=np.int64), np.zeros(0, dtype=np.float32))
    return np.asarray(xs), np.asarray(gs), np.asarray(ys), np.asarray(ws, dtype=np.float32)


def train_sasrec(fb, item_to_idx):
    """Fit a compact causal self-attention next-click model on the VM at predict time."""
    try:
        import torch
        from torch import nn
        import torch.nn.functional as F
    except Exception as exc:
        print("torch unavailable; using CTR fallback:", exc)
        return None, None

    sequences = click_sequences(fb, item_to_idx)
    X, G, y, weights = make_weighted_examples(fb, item_to_idx, MAX_SEQ_LEN)
    n_items = len(item_to_idx)
    if n_items == 0 or len(y) < 100:
        print("too few SASRec examples; using CTR fallback:", len(y))
        return None, sequences

    torch.set_num_threads(max(1, min(4, os.cpu_count() or 1)))
    torch.manual_seed(SEED)
    device = torch.device("cpu")

    class SASRec(nn.Module):
        def __init__(self):
            super().__init__()
            self.item_emb = nn.Embedding(n_items + 1, D_MODEL, padding_idx=0)
            self.pos_emb = nn.Embedding(MAX_SEQ_LEN, D_MODEL)
            self.gap_emb = nn.Embedding(N_GAP_BUCKETS, D_MODEL, padding_idx=0)
            self.in_norm = nn.LayerNorm(D_MODEL)
            self.in_drop = nn.Dropout(DROPOUT)
            layer = nn.TransformerEncoderLayer(
                d_model=D_MODEL, nhead=N_HEADS, dim_feedforward=4 * D_MODEL,
                dropout=DROPOUT, activation="gelu", batch_first=True, norm_first=False
            )
            self.encoder = nn.TransformerEncoder(layer, num_layers=N_LAYERS)
            self.out_norm = nn.LayerNorm(D_MODEL)
            self.item_bias = nn.Parameter(torch.zeros(n_items))
            nn.init.normal_(self.item_emb.weight, mean=0.0, std=0.02)
            with torch.no_grad():
                self.item_emb.weight[0].zero_()
                self.gap_emb.weight[0].zero_()

        def encode(self, seq, gap):
            batch, length = seq.shape
            pos = torch.arange(length, device=seq.device).unsqueeze(0).expand(batch, length)
            x = self.item_emb(seq) + self.pos_emb(pos) + self.gap_emb(gap)
            x = self.in_drop(self.in_norm(x))
            mask = torch.triu(torch.ones(length, length, device=seq.device, dtype=torch.bool), diagonal=1)
            x = self.encoder(x, mask=mask)
            last = (seq != 0).sum(dim=1).clamp(min=1) - 1
            h = x[torch.arange(batch, device=seq.device), last]
            return self.out_norm(h)

        def score(self, h):
            return h @ self.item_emb.weight[1:].T + self.item_bias

    model = SASRec().to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=LEARNING_RATE, weight_decay=1e-5)
    rng = np.random.default_rng(SEED)
    y_class = y - 1
    for epoch in range(EPOCHS):
        model.train()
        order = rng.permutation(len(y))
        running = 0.0
        batches = 0
        for start in range(0, len(order), BATCH_SIZE):
            ix = order[start:start + BATCH_SIZE]
            seq = torch.from_numpy(X[ix]).to(device)
            gap = torch.from_numpy(G[ix]).to(device)
            target = torch.from_numpy(y_class[ix]).long().to(device)
            sample_w = torch.from_numpy(weights[ix]).to(device)
            opt.zero_grad(set_to_none=True)
            logits = model.score(model.encode(seq, gap))
            loss_each = F.cross_entropy(logits, target, reduction="none")
            loss = (loss_each * sample_w).sum() / sample_w.sum().clamp(min=1e-8)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            running += float(loss.detach())
            batches += 1
        print(f"SASRec epoch {epoch + 1}/{EPOCHS}: loss={running / max(batches, 1):.4f}")
    model.eval()
    return (model, torch, device), sequences


def smoothed_ctr_order(fb, catalog):
    """Recency-smoothed click-through prior for cold users and fallback."""
    items = catalog["itemID"].astype(str).to_numpy()
    if fb.empty:
        return items
    ts = fb["timestamp"].to_numpy(dtype=np.float64)
    w = 0.5 ** ((ts.max() - ts) / (HALF_LIFE_DAYS * DAY))
    grouped = pd.DataFrame({"itemID": fb["itemID"].to_numpy(),
                            "w": w,
                            "wc": w * fb["clicked"].to_numpy(dtype=np.float64)}).groupby("itemID")[["w", "wc"]].sum()
    base = float(fb["clicked"].mean())
    ctr = (grouped["wc"] + CTR_PRIOR * base) / (grouped["w"] + CTR_PRIOR)
    score = pd.Series(items).map(ctr).fillna(base).to_numpy(dtype=np.float64)
    order = np.lexsort((items, -score))
    return items[order]


def user_top_items(model_pack, sequences, item_to_idx, catalog_items, requested_users=None):
    """Cache each requested warm user's top SASRec items to bound inference memory."""
    if model_pack is None:
        return {}
    model, torch, device = model_pack
    requested_users = set(requested_users) if requested_users is not None else None
    wanted = [u for u in sequences if len(sequences[u][0]) > 0 and
              (requested_users is None or u in requested_users)]
    if not wanted:
        return {}
    catalog_items = np.asarray(catalog_items, dtype=object)
    cat_idx = np.asarray([item_to_idx[x] for x in catalog_items], dtype=np.int64)
    col_idx = torch.from_numpy(cat_idx - 1).long().to(device)
    result = {}
    model.eval()
    with torch.no_grad():
        for start in range(0, len(wanted), 128):
            users = wanted[start:start + 128]
            xs = np.zeros((len(users), MAX_SEQ_LEN), dtype=np.int64)
            gs = np.zeros((len(users), MAX_SEQ_LEN), dtype=np.int64)
            for j, user in enumerate(users):
                ids, gaps = sequences[user]
                ids, gaps = ids[-MAX_SEQ_LEN:], gaps[-MAX_SEQ_LEN:]
                xs[j, :len(ids)] = ids
                gs[j, :len(gaps)] = gaps
            seq = torch.from_numpy(xs).to(device)
            gap = torch.from_numpy(gs).to(device)
            scores = model.score(model.encode(seq, gap)).index_select(1, col_idx).cpu().numpy()
            k = min(TOP_K, len(catalog_items))
            for j, user in enumerate(users):
                if k == len(catalog_items):
                    loc = np.argsort(-scores[j], kind="stable")
                else:
                    loc = np.argpartition(scores[j], -k)[-k:]
                    loc = loc[np.argsort(-scores[j, loc], kind="stable")]
                result[user] = [(str(catalog_items[q]), float(scores[j, q])) for q in loc]
    return result


def recommend(fb, rows, catalog):
    """Return one valid item per request, with user-sequential exposure rotation."""
    catalog = catalog.copy()
    catalog["itemID"] = catalog["itemID"].astype(str)
    catalog = catalog.drop_duplicates("itemID").reset_index(drop=True)
    catalog["valid_from"] = catalog["valid_from"].astype("int64")
    catalog["valid_to"] = catalog["valid_to"].astype("int64")
    rows = rows.copy()
    rows["rowid"] = rows["rowid"].astype(str)
    rows["user_id"] = rows["user_id"].astype(str)
    rows["timestamp"] = rows["timestamp"].astype("int64")

    vocab_items = sorted(set(catalog["itemID"].tolist()) | set(fb["itemID"].astype(str).tolist()))
    item_to_idx = {item: i + 1 for i, item in enumerate(vocab_items)}
    model_pack, sequences = train_sasrec(fb, item_to_idx)
    global_order = smoothed_ctr_order(fb, catalog)
    sasrec_order = user_top_items(
        model_pack, sequences or {}, item_to_idx, catalog["itemID"].to_numpy(), rows["user_id"].unique()
    )

    live_from = catalog.set_index("itemID")["valid_from"].to_dict()
    live_to = catalog.set_index("itemID")["valid_to"].to_dict()
    clicked_pairs = set(map(tuple, fb.loc[fb["clicked"] == 1, ["user_id", "itemID"]].astype(str).to_numpy()))
    rejected_pairs = set()
    if SKIP_REJECTED and len(fb):
        pair_click = fb.groupby(["user_id", "itemID"])["clicked"].max()
        rejected_pairs = set(pair_click[pair_click == 0].index)
    simulated = set()
    output = {}
    ordered = rows.sort_values(["timestamp", "rowid"], kind="stable")

    def available(item, ts):
        return item in live_from and live_from[item] <= ts < live_to[item]

    def choose(order, user, ts, prefer_fresh):
        # First avoid known non-clicks and already simulated non-click exposures.
        for item, _ in order:
            if not available(item, ts) or (user, item) in rejected_pairs:
                continue
            if prefer_fresh and SIM_EXPOSURE and (user, item) in simulated and (user, item) not in clicked_pairs:
                continue
            return item
        return None

    for r in ordered.itertuples(index=False):
        user, ts = str(r.user_id), int(r.timestamp)
        order = sasrec_order.get(user, [])
        pick = choose(order, user, ts, True)
        if pick is None:
            pick = choose([(item, 0.0) for item in global_order], user, ts, True)
        if pick is None:
            # If every active item was previously rejected/recommended, relax those preferences.
            pick = choose(order, user, ts, False)
        if pick is None:
            pick = choose([(item, 0.0) for item in global_order], user, ts, False)
        if pick is None:
            active = [it for it in catalog["itemID"].tolist() if available(it, ts)]
            pick = active[0] if active else catalog["itemID"].iloc[0]
        output[r.rowid] = pick
        simulated.add((user, pick))

    return [(str(r), str(output[str(r)])) for r in rows["rowid"].tolist()]


def predict(data_dir, batch_size=256):
    data = Path(data_dir)
    rows = read_any(data, "x_pred", dtype={"rowid": str, "user_id": str})
    rows = rows.astype({"rowid": str, "user_id": str}).drop_duplicates("rowid")
    rows["timestamp"] = rows["timestamp"].astype("int64")
    catalog = read_any(data, "catalog", dtype={"itemID": str})
    catalog["itemID"] = catalog["itemID"].astype(str)
    try:
        fb = load_feedback(data)
    except Exception as exc:
        print("feedback load failed; using popularity fallback:", exc)
        fb = pd.DataFrame(columns=["event_id", "user_id", "timestamp", "itemID", "clicked"])
    fb = fb.astype({"event_id": str, "user_id": str, "itemID": str})
    result = recommend(fb, rows, catalog)
    for start in range(0, len(result), batch_size):
        yield result[start:start + batch_size]
