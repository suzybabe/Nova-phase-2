"""Team Nova - Round 3 item-quality + co-click candidate.

Based on the team's shared Round 3 v2 solution. Item quality is a recency-weighted,
smoothed click-through rate; personalization is user-item co-click similarity. The
matching leave-last-click-out validator is in validate_leave_last_out.py.

This remains an experimental candidate until validated on the VM using the Round 3
starter/evaluator. Dependencies: numpy, pandas, scipy.
"""
import csv
import json
import sys
import tempfile
import time
from pathlib import Path

import numpy as np
import pandas as pd
import scipy.sparse as sp

PRIOR = 200.0
HALF_LIFE_D = 1.0
BETA = 0.5
USER_CHUNK = 500
DAY = 86400.0


def load_feedback(data_dir):
    """Read canonical feedback.jsonl; expand its displayed slates into long rows.

    Uses a temporary CSV spool to avoid retaining millions of Python tuples while parsing.
    """
    data = Path(data_dir)
    canonical = data / "feedback.jsonl"
    if canonical.exists():
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="", suffix=".csv") as tmp:
            writer = csv.writer(tmp)
            writer.writerow(["event_id", "user_id", "timestamp", "itemID", "clicked"])
            malformed = missing = click_not_shown = duplicate_items = 0
            with canonical.open(encoding="utf-8") as src:
                for line in src:
                    try:
                        e = json.loads(line)
                    except Exception:
                        malformed += 1
                        continue
                    if not all(k in e for k in ("event_id", "user_id", "timestamp", "displayed_items")):
                        missing += 1
                        continue
                    slate = [str(item) for item in e["displayed_items"] if item is not None]
                    unique_slate = list(dict.fromkeys(slate))
                    duplicate_items += len(slate) - len(unique_slate)
                    clicked = e.get("clicked_item")
                    clicked = str(clicked) if clicked is not None else None
                    if clicked is not None and clicked not in unique_slate:
                        click_not_shown += 1
                        clicked = None
                    event_id, user_id = str(e["event_id"]), str(e["user_id"])
                    timestamp = int(e["timestamp"])
                    writer.writerows((event_id, user_id, timestamp, item, int(item == clicked))
                                     for item in unique_slate)
            tmp.flush()
            fb = pd.read_csv(tmp.name, dtype={"event_id": str, "user_id": str, "itemID": str})
        print(f"feedback cleaning: malformed={malformed}, missing={missing}, "
              f"click_not_shown={click_not_shown}, duplicate_slate_items={duplicate_items}",
              file=sys.stderr, flush=True)
    else:
        # The competition bundle provides a redundant long table if canonical JSONL is absent.
        csv_path = data / "feedback_long.csv"
        pq_path = data / "feedback_long.parquet"
        if csv_path.exists():
            fb = pd.read_csv(csv_path, usecols=["event_id", "user_id", "timestamp", "itemID", "clicked"],
                             dtype={"event_id": str, "user_id": str, "itemID": str})
        elif pq_path.exists():
            fb = pd.read_parquet(pq_path, columns=["event_id", "user_id", "timestamp", "itemID", "clicked"])
        else:
            raise FileNotFoundError("feedback.jsonl or feedback_long table is required")
    fb["timestamp"] = fb["timestamp"].astype(np.int64)
    fb["clicked"] = fb["clicked"].astype(np.int8)
    fb["event_id"] = fb["event_id"].astype(str)
    fb["user_id"] = fb["user_id"].astype(str)
    fb["itemID"] = fb["itemID"].astype(str)
    return fb.drop_duplicates(["event_id", "itemID"], keep="first")


def load(data_dir):
    """Load canonical CSV inputs and canonical JSONL feedback."""
    data = Path(data_dir)
    fl = load_feedback(data)
    cat = pd.read_csv(data / "catalog.csv", dtype={"itemID": str})
    xp = pd.read_csv(data / "x_pred.csv", dtype={"rowid": str, "user_id": str})
    xp["timestamp"] = xp["timestamp"].astype(np.int64)
    cat["valid_from"] = cat["valid_from"].astype(np.int64)
    cat["valid_to"] = cat["valid_to"].astype(np.int64)
    return fl, cat, xp


class ItemQuality:
    def __init__(self, prior=PRIOR, half_life_d=HALF_LIFE_D, beta=BETA):
        self.prior = float(prior)
        self.hl = half_life_d
        self.beta = float(beta)

    def fit(self, fl, cat):
        fl = fl[["event_id", "user_id", "timestamp", "itemID", "clicked"]].copy()
        fl["user_id"] = fl["user_id"].astype(str)
        fl["itemID"] = fl["itemID"].astype(str)
        fl["timestamp"] = fl["timestamp"].astype(np.int64)
        fl["clicked"] = fl["clicked"].astype(np.int8)
        cat_items = pd.Index(cat["itemID"].astype(str).unique())
        self.items = pd.Index(sorted(set(fl["itemID"]) | set(cat_items)))
        if len(fl) == 0:
            self.logctr = np.zeros(len(self.items), dtype=np.float64)
            self.users = pd.Index([])
            self.X = sp.csr_matrix((0, len(self.items)), dtype=np.float32)
            self.Cn = sp.csr_matrix((len(self.items), len(self.items)), dtype=np.float32)
            self.CnT = self.Cn.T.tocsr()
            self.cf_sd = 1.0
            return self

        ts = fl["timestamp"].to_numpy(dtype=np.float64)
        if self.hl is None:
            w = np.ones(len(fl), dtype=np.float64)
        else:
            w = 0.5 ** ((ts.max() - ts) / (float(self.hl) * DAY))
        ii = self.items.get_indexer(fl["itemID"])
        imp = np.bincount(ii, weights=w, minlength=len(self.items))
        clk = np.bincount(ii, weights=w * fl["clicked"].to_numpy(dtype=np.float64), minlength=len(self.items))
        p0 = clk.sum() / max(imp.sum(), 1e-9)
        self.logctr = np.log((clk + self.prior * p0) / (imp + self.prior))

        c = fl.loc[fl["clicked"] == 1, ["user_id", "itemID"]].drop_duplicates()
        self.users = pd.Index(sorted(c["user_id"].unique()))
        rr = self.users.get_indexer(c["user_id"])
        cc = self.items.get_indexer(c["itemID"])
        self.X = sp.csr_matrix((np.ones(len(c), dtype=np.float32), (rr, cc)),
                               shape=(len(self.users), len(self.items)), dtype=np.float32)
        # Binary user-item history: repeat clicks do not increase the co-click graph degree.
        self.X.data[:] = 1.0
        co = (self.X.T @ self.X).tocsr()
        co.setdiag(0)
        co.eliminate_zeros()
        degree = np.asarray(self.X.sum(axis=0)).ravel().astype(np.float64) + 1e-9
        self.Cn = co.multiply((1.0 / np.sqrt(degree))[None, :]).tocsr().astype(np.float32)
        self.CnT = self.Cn.T.tocsr()

        sample = fl.sample(n=min(len(fl), 200000), random_state=0)
        su = self.users.get_indexer(sample["user_id"])
        si = self.items.get_indexer(sample["itemID"])
        self.cf_sd = float(self._cf_pairs(su, si).std()) + 1e-9
        return self

    def _cf_pairs(self, user_idx, item_idx):
        out = np.zeros(len(user_idx), dtype=np.float64)
        ok = (user_idx >= 0) & (item_idx >= 0)
        if ok.any():
            out[ok] = np.asarray(self.X[user_idx[ok]].multiply(self.CnT[item_idx[ok]]).sum(axis=1)).ravel()
        return out

    def user_scores(self, user_idx):
        scores = np.tile(self.logctr.astype(np.float32), (len(user_idx), 1))
        if self.beta:
            known = user_idx >= 0
            if known.any():
                cf = (self.X[user_idx[known]] @ self.Cn).toarray()
                scores[known] += (self.beta / self.cf_sd) * cf.astype(np.float32)
        return scores

    def score_pairs(self, users, items):
        """Score paired users/items, used by leave-last-out evaluation."""
        users = np.asarray(users, dtype=str)
        items = np.asarray(items, dtype=str)
        if users.shape != items.shape:
            raise ValueError("users and items must have the same shape")
        ui = self.users.get_indexer(pd.Index(users))
        ii = self.items.get_indexer(pd.Index(items))
        base = np.zeros(len(items), dtype=np.float64)
        valid = ii >= 0
        base[valid] = self.logctr[ii[valid]]
        if self.beta:
            base += (self.beta / self.cf_sd) * self._cf_pairs(ui, ii)
        return base

    def recommend(self, xp, cat):
        ci = self.items.get_indexer(cat.itemID.astype(str))
        if (ci < 0).any():
            raise ValueError("catalog item missing from fitted item index")
        vf = cat.valid_from.to_numpy(np.int64)
        vt = cat.valid_to.to_numpy(np.int64)
        cat_items = cat.itemID.astype(str).to_numpy()
        recs = np.empty(len(xp), dtype=object)
        xs = xp.assign(_r=np.arange(len(xp))).sort_values("user_id", kind="stable")
        ulist = xs.user_id.astype(str).unique()
        for start in range(0, len(ulist), USER_CHUNK):
            us = ulist[start:start + USER_CHUNK]
            S = self.user_scores(self.users.get_indexer(pd.Index(us)))[:, ci]
            pos = pd.Series(np.arange(len(us)), index=us)
            part = xs[xs.user_id.astype(str).isin(us)]
            row_ids = part._r.to_numpy()
            times = part.timestamp.to_numpy(np.int64)[:, None]
            scores = S[pos.reindex(part.user_id.astype(str)).to_numpy()]
            live = (vf[None, :] <= times) & (times < vt[None, :])
            scores[~live] = -np.inf
            best = scores.argmax(axis=1)
            dead = ~np.isfinite(scores[np.arange(len(best)), best])
            recs[row_ids] = cat_items[best]
            if dead.any():
                for j in np.flatnonzero(dead):
                    live_idx = np.flatnonzero((vf <= times[j, 0]) & (times[j, 0] < vt))
                    recs[row_ids[j]] = cat_items[live_idx[0] if len(live_idx) else 0]
        return recs


def predict(data_dir, batch_size=256):
    start = time.time()
    fl, cat, xp = load(data_dir)
    xp = xp.drop_duplicates("rowid", keep="first").reset_index(drop=True)
    model = ItemQuality().fit(fl, cat)
    recs = model.recommend(xp, cat)
    print(f"[nova-r3-llo] done {time.time()-start:.1f}s, distinct items {len(set(recs))}",
          file=sys.stderr, flush=True)
    out = []
    for rowid, item in zip(xp.rowid.to_numpy(), recs):
        out.append((str(rowid), str(item)))
        if len(out) >= batch_size:
            yield out
            out = []
    if out:
        yield out
