Ady - Round 4 solution (numpy / pandas / scipy only, CPU, no torch, nothing shipped: it trains inside predict())

What it does
  Picks, for each request, the item the user has clicked most often that is available at that time (ties: most recent click).
  Users with no usable click history get the best item from a choice model fitted on the real pooled slates inside the data.

Why (tested on round 3's real slates, now inside the round 4 feedback; train 9-10 Jan, predict 11-13 Jan, 240k rows)
  share of clicked rows where the user chose our pick:  this solution 67.7% | most recent click 66.5% | Susan's v2 16.3%
  The round 3 simulator mostly re-picks items the user clicked before (86% vs 37% by chance).

Run on the VM:
  cd ~/ady_r4
  /opt/techarena/venvs/torch/bin/python check_r4.py ~/data/round-4/phase-2-round-4-input
Expected: "R4 VERDICT: OK", 400,000 rows, 100% available, about 50 s on CPU.

To submit: zip solution.py on its own, run  sudo check-submission <zip>, and agree with the team before uploading
(only the last upload counts).
