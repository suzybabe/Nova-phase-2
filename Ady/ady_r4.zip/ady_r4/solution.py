"""Team Nova - Round 4 solution (Ady): habit choice model fitted on the real pooled slates.

Why: round 3's pooled slates (the 400k most recent events of feedback) show how the simulator really chooses:
a user mostly picks an item they clicked before, more so the more recently and the more often they clicked it
(held-out hit@1 0.74 vs 0.41 for item popularity alone). The random-slate logger days (6-8 Jan) show almost none of this.

How it works (numpy / pandas / scipy only, nothing shipped, trained inside predict() on the round's own data):
  1. Per (user, item): clicks before, time of last click, exposures before - built for every impression, vectorised.
  2. Fit a conditional-logit choice model on the pooled slates that contain exactly one click:
        utility = recency bucket of last click + log(1+clicks) + exposure terms (fatigue) + item bias (top items).
  3. For every request: candidates = items the user clicked before + the globally strongest items, restricted to
     items available at the request time; recommend the candidate with the highest utility.
Pooled days are detected from the data (slate-size distribution), not hard-coded, so the file also works on later rounds.
"""
import sys, time
from pathlib import Path
import numpy as np, pandas as pd
from scipy.optimize import minimize

USE_EXPOSURE = False         # exposure (fatigue) terms: unstable weights + stale counts at serving -> off (see IDEAS)
STRATEGY = "most_clicked"     # "most_clicked": user's most-clicked live item (ties: most recent), model only as fallback
                             # "model": highest choice-model utility among clicked + top items
TOPK = 30                     # globally strongest items that get their own bias term and are always candidates
LAM = 1.0                     # L2 on the choice-model weights
AGE_EDGES = [0, 6, 12, 24, 48, 72, 1e9]      # hours since the last click -> 6 recency buckets
USER_CHUNK = 1500
POOLED_SIZE3_MAX = 0.90       # a day counts as "pooled" if fewer than 90% of its events have exactly 3 items
BIG = 1 << 33


def log(*a):
    print("[nova-r4]", *a, file=sys.stderr, flush=True)


def load(data_dir):
    d = Path(data_dir)
    fl = pd.read_parquet(d / "feedback_long.parquet") if (d / "feedback_long.parquet").exists() \
        else pd.read_csv(d / "feedback_long.csv")
    fl = fl[["event_id", "user_id", "timestamp", "itemID", "clicked"]].copy()
    fl["user_id"] = fl["user_id"].astype(str); fl["itemID"] = fl["itemID"].astype(str)
    fl["timestamp"] = fl["timestamp"].astype(np.int64); fl["clicked"] = fl["clicked"].astype(np.int8)
    cat = pd.read_csv(d / "catalog.csv", dtype={"itemID": str})
    xp = pd.read_csv(d / "x_pred.csv", dtype={"rowid": str, "user_id": str})
    xp["timestamp"] = xp["timestamp"].astype(np.int64)
    return fl, cat, xp


def history_features(fl):
    """For every impression: clicks of (user,item) strictly before, last click time before, exposures before.
    Also returns one row per (user,item) with the totals (the state at the end of the feedback)."""
    uc, uniq_u = pd.factorize(fl.user_id)
    ic, uniq_i = pd.factorize(fl.itemID)
    key = uc.astype(np.int64) * len(uniq_i) + ic
    ts = fl.timestamp.to_numpy(); clk = fl.clicked.to_numpy().astype(np.int64)
    order = np.lexsort((ts, key))
    k, t, c = key[order], ts[order], clk[order]
    start = np.r_[True, k[1:] != k[:-1]]
    g = np.cumsum(start) - 1
    first_idx = np.flatnonzero(start)
    pos = np.arange(len(k)) - first_idx[g]                       # exposures before (within group)
    cs = np.cumsum(c)
    base = (cs - c)[first_idx][g]
    prior_clicks = cs - c - base
    val = np.where(c == 1, t, 0); sh = np.r_[0, val[:-1]]; sh[start] = 0
    acc = np.maximum.accumulate(g.astype(np.int64) * BIG + sh)
    last = acc - g.astype(np.int64) * BIG                       # 0 = never clicked before
    n_imp = len(fl)
    out = {nm: np.empty(n_imp, dtype=np.int64) for nm in ("nclk", "last", "seen")}
    out["nclk"][order] = prior_clicks; out["last"][order] = last; out["seen"][order] = pos
    # totals per (user, item)
    end_idx = np.r_[first_idx[1:] - 1, len(k) - 1]
    tot = pd.DataFrame({"u": uc[order][end_idx], "i": ic[order][end_idx],
                        "n": prior_clicks[end_idx] + c[end_idx],
                        "last": np.maximum(last[end_idx], np.where(c[end_idx] == 1, t[end_idx], 0)),
                        "seen": pos[end_idx] + 1})
    return out, tot, uniq_u, uniq_i, uc, ic


def design(nclk, last, seen, ts, topidx, K, exposure=None):
    exposure = USE_EXPOSURE if exposure is None else exposure
    """Rows of features for (n prior clicks, last click time, exposures, request time, top-item index or -1)."""
    X = np.zeros((len(nclk), 10 + K), dtype=np.float64)
    has = nclk > 0
    age = np.where(has, (ts - last) / 3600.0, 0.0)
    b = np.clip(np.searchsorted(AGE_EDGES, age, side="right") - 1, 0, 5)
    r = np.flatnonzero(has)
    X[r, b[r]] = 1.0
    X[r, 6] = np.log1p(nclk[r])
    r0 = np.flatnonzero(~has)
    if exposure:
        X[r, 8] = np.log1p(seen[r]); X[r, 9] = np.log1p(seen[r] / np.maximum(nclk[r], 1))
        X[r0, 7] = np.log1p(seen[r0])
    t = np.flatnonzero(topidx >= 0)
    X[t, 10 + topidx[t]] = 1.0
    return X


def fit_choice(fl, hf, uniq_i):
    """Conditional logit on pooled slates with exactly one click. Returns (weights, top item codes)."""
    n = fl.groupby("event_id").itemID.transform("size").to_numpy()
    ev_clicks = fl.groupby("event_id").clicked.transform("sum").to_numpy()
    day = (fl.timestamp.to_numpy() // 86400)
    ev_first = fl.assign(n=n).groupby("event_id").agg(day=("timestamp", lambda s: s.iloc[0] // 86400), n=("n", "first"))
    frac3 = ev_first.groupby("day").n.apply(lambda s: (s == 3).mean())
    pooled_days = set(frac3[frac3 < POOLED_SIZE3_MAX].index)
    use = np.isin(day, list(pooled_days)) & (ev_clicks == 1) & (n >= 2)
    log("pooled days", sorted(pooled_days), "| training impressions", int(use.sum()))
    if use.sum() < 5000:
        return None, None
    sub = fl[use]; ic = pd.Index(uniq_i).get_indexer(sub.itemID)
    cnt = np.bincount(ic, minlength=len(uniq_i)); top = np.argsort(-cnt)[:TOPK]
    topmap = np.full(len(uniq_i), -1); topmap[top] = np.arange(len(top))
    X = design(hf["nclk"][use], hf["last"][use], hf["seen"][use], sub.timestamp.to_numpy(), topmap[ic], len(top))
    ev = pd.factorize(sub.event_id)[0]; E = ev.max() + 1
    p = sub.groupby("event_id", sort=False).cumcount().to_numpy(); Kmax = int(p.max()) + 1
    F = np.zeros((E, Kmax, X.shape[1])); M = np.zeros((E, Kmax), bool); Y = np.zeros(E, dtype=np.int64)
    F[ev, p] = X; M[ev, p] = True
    Y[ev[sub.clicked.to_numpy() == 1]] = p[sub.clicked.to_numpy() == 1]

    def nll(w):
        s = np.where(M, F @ w, -1e9); s -= s.max(1, keepdims=True)
        pr = np.exp(s); pr /= pr.sum(1, keepdims=True)
        L = -np.log(pr[np.arange(E), Y] + 1e-12).sum() + LAM * w @ w
        d = pr.copy(); d[np.arange(E), Y] -= 1.0
        return L, np.einsum("ek,ekf->f", d, F) + 2 * LAM * w
    w = minimize(nll, np.zeros(X.shape[1]), jac=True, method="L-BFGS-B", options={"maxiter": 300}).x
    log("fit on", E, "slates | recency", np.round(w[:6], 2), "| log clicks", round(w[6], 2),
        "| seen(never) %.2f seen(clicked) %.2f per-click %.2f" % (w[7], w[8], w[9]))
    return w, top


def recommend(fl_all, cat, xp, w, top, hf_tot, uniq_u, uniq_i):
    items = cat.itemID.to_numpy(); vf = cat.valid_from.to_numpy(np.int64); vt = cat.valid_to.to_numpy(np.int64)
    icode = pd.Index(uniq_i).get_indexer(items)                      # catalogue -> item code (-1 = never in feedback)
    topset = [int(t) for t in top]
    K = len(top); topmap = {t: k for k, t in enumerate(topset)}
    # catalogue index per item code
    code2cat = {int(c): j for j, c in enumerate(icode) if c >= 0}
    tot = hf_tot
    users = pd.Index(uniq_u).get_indexer(xp.user_id.unique())
    recs = np.empty(len(xp), dtype=object)
    xp = xp.assign(_r=np.arange(len(xp)), _u=pd.Index(uniq_u).get_indexer(xp.user_id))
    tot_by_user = {int(u): d for u, d in tot[tot.u.isin(users[users >= 0])].groupby("u")}
    top_in_cat = [(t, code2cat[t]) for t in topset if t in code2cat]
    ulist = xp.user_id.unique()
    for s in range(0, len(ulist), USER_CHUNK):
        part = xp[xp.user_id.isin(ulist[s:s + USER_CHUNK])]
        us = np.unique(part._u.to_numpy()); us_known = us[us >= 0]
        sel = tot[tot.u.isin(us_known)]
        clicked = sel[sel.n > 0][["u", "i", "n", "last", "seen"]]
        # top items for every user in the chunk (features from totals if the user has met them)
        grid = pd.DataFrame([(u, t) for u in us for t, _ in top_in_cat], columns=["u", "i"])
        gtop = grid.merge(sel[["u", "i", "n", "last", "seen"]], on=["u", "i"], how="left").fillna(0)
        cand = pd.concat([clicked, gtop]).drop_duplicates(["u", "i"], keep="first")
        cand["cat"] = cand.i.map(code2cat)
        cand = cand[cand.cat.notna()].copy(); cand["cat"] = cand.cat.astype(int)
        m = part[["_r", "_u", "timestamp"]].merge(cand, left_on="_u", right_on="u")
        t = m.timestamp.to_numpy()
        ok = (vf[m.cat.to_numpy()] <= t) & (t < vt[m.cat.to_numpy()])
        m = m[ok]; t = t[ok]
        X = design(m.n.to_numpy().astype(np.int64), m["last"].to_numpy().astype(np.int64), m.seen.to_numpy().astype(np.int64),
                   t, np.array([topmap.get(int(i), -1) for i in m.i.to_numpy()]), K)
        m = m.assign(score=X @ w)
        if STRATEGY == "most_clicked":
            m = m.assign(_c=(m.n.to_numpy() > 0).astype(int))
            best = m.sort_values(["_r", "_c", "n", "last", "score"]).drop_duplicates("_r", keep="last")
        else:
            best = m.loc[m.groupby("_r").score.idxmax()]
        recs[best._r.to_numpy()] = items[best.cat.to_numpy()]
    # rows with no available candidate: first live item
    miss = np.flatnonzero(pd.isna(pd.Series(recs)).to_numpy())
    if len(miss):
        ts = xp.timestamp.to_numpy()
        for j in miss:
            live = np.flatnonzero((vf <= ts[j]) & (ts[j] < vt))
            recs[j] = items[live[0] if len(live) else 0]
    return recs


def predict(data_dir, batch_size=256):
    t0 = time.time()
    fl, cat, xp = load(data_dir)
    xp = xp.drop_duplicates("rowid").reset_index(drop=True)
    hf, tot, uniq_u, uniq_i, uc, ic = history_features(fl)
    log("features", round(time.time() - t0, 1), "s |", len(fl), "impressions")
    w, top = fit_choice(fl, hf, uniq_i)
    if w is None:                                    # no pooled data: fall back to most-recent click, else first live item
        w = np.zeros(10 + TOPK); w[:6] = [3, 2.5, 2, 1.5, 1, 0.5]; w[6] = 1.0
        n = np.bincount(ic[fl.clicked.to_numpy() == 1], minlength=len(uniq_i)); top = np.argsort(-n)[:TOPK]
    recs = recommend(fl, cat, xp, w, top, tot, uniq_u, uniq_i)
    log("done", round(time.time() - t0, 1), "s | distinct items", len(set(recs)))
    out = []
    for rid, it in zip(xp.rowid.to_numpy(), recs):
        out.append((str(rid), str(it)))
        if len(out) >= batch_size:
            yield out; out = []
    if out:
        yield out


if __name__ == "__main__":
    print("rows:", sum(len(b) for b in predict(sys.argv[1] if len(sys.argv) > 1 else ".")))
