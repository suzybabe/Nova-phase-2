"""Evaluate a round 4 solution.py on round 3's REAL pooled slates (they are inside the round 4 feedback).

Idea ("replay"): pretend it is 11 Jan. Give the solution only the feedback before 11 Jan, ask it to answer the
round 3 requests from 11-13 Jan, then look at what the real users actually clicked on those days.
Score = of the requests where the user clicked something, how often they clicked OUR pick.
That is close to what the official score measures (P(our item is chosen | the user clicks)).

Run:  python evaluate_r4.py <round 4 data folder> [solution.py ...]
      (default: ./solution.py; give several files to compare them side by side)
"""
import sys, time, tempfile, importlib.util
from pathlib import Path
import numpy as np, pandas as pd

D = Path(sys.argv[1]); sols = sys.argv[2:] or [str(Path(__file__).resolve().parent / "solution.py")]
fl = pd.read_parquet(D / "feedback_long.parquet") if (D / "feedback_long.parquet").exists() else pd.read_csv(D / "feedback_long.csv")
fl["timestamp"] = fl["timestamp"].astype("int64")

# pooled (real multi-team) days = days where most slates are NOT exactly 3 items
ev = fl.groupby("event_id").agg(t=("timestamp", "first"), n=("itemID", "size"))
frac3 = (ev.n == 3).groupby(ev.t // 86400).mean()
pooled = sorted(frac3[frac3 < 0.9].index)
if len(pooled) < 3:
    sys.exit("need at least 3 pooled days in the feedback to evaluate")
cut = int(pooled[2]) * 86400                       # train on the first 2 pooled days (+ all logger days), test on the rest
print(f"pooled days found: {len(pooled)} | training on feedback before {pd.to_datetime(cut, unit='s'):%d %b} | testing after")

# test set: the real slates after the cut, one per request
te = fl[fl.timestamp >= cut]
slates = te.groupby("event_id").agg(user_id=("user_id", "first"), timestamp=("timestamp", "first"),
                                    items=("itemID", list), lab=("clicked", list)).reset_index()
slates = slates.drop_duplicates(["user_id", "timestamp"]).reset_index(drop=True)
slates["rowid"] = "t" + slates.index.astype(str)
clicked = slates[[sum(l) == 1 for l in slates.lab]].copy()
clicked["chosen"] = [it[l.index(1)] for it, l in zip(clicked["items"], clicked.lab)]

# build the "past" data folder the solution will see
tmp = Path(tempfile.mkdtemp())
fl[fl.timestamp < cut].to_parquet(tmp / "feedback_long.parquet", index=False)
slates[["rowid", "user_id", "timestamp"]].to_csv(tmp / "x_pred.csv", index=False)
cat = pd.read_csv(D / "catalog.csv")
cat_all = pd.DataFrame({"itemID": sorted(set(fl.itemID) | set(cat.itemID)), "valid_from": 0, "valid_to": 2**40})
cat_all.to_csv(tmp / "catalog.csv", index=False)     # every item counted as live: the round 3 catalogue is not in this folder
print(f"test requests {len(slates):,} | of which the user clicked something: {len(clicked):,}\n")

print(f"{'solution':<45}{'pick in real slate':>20}{'user chose our pick':>22}{'seconds':>9}")
for p in sols:
    sp = importlib.util.spec_from_file_location("sol", p); m = importlib.util.module_from_spec(sp); sp.loader.exec_module(m)
    t0 = time.time(); picks = dict(x for b in m.predict(str(tmp)) for x in b); secs = time.time() - t0
    pk = clicked.rowid.map(picks)
    inn = np.array([a in s for a, s in zip(pk, clicked["items"])])
    won = (pk == clicked.chosen).to_numpy()
    print(f"{p[-45:]:<45}{inn.mean():>19.1%}{won.mean():>21.1%}{secs:>9.0f}")
print("\nHigher 'user chose our pick' is better. Differences under ~0.7 points are noise (95% margin).")
