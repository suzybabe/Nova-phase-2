Ady - Round 4 solution (numpy / pandas / scipy only, CPU, no torch, nothing shipped: it trains inside predict())

What it does
  Picks, for each request, the item the user has clicked most often that is available at that time (ties: most recent click).
  Users with no usable click history (about 16% of round 4 requests) get the item that first-time clickers chose most
  often in the real pooled slates (needs 300+ such slates as evidence), if it is available at the request time.

Why (tested on round 3's real slates, now inside the round 4 feedback; train 9-10 Jan, predict 11-13 Jan, 240k rows)
  share of clicked rows where the user chose our pick:  this solution 67.7% | most recent click 66.5% | Susan's v2 16.3%
  The round 3 simulator mostly re-picks items the user clicked before (86% vs 37% by chance).

Run on the VM:
  cd ~/ady_r4_v2
  /opt/techarena/venvs/torch/bin/python check_r4.py ~/data/round-4/phase-2-round-4-input
Expected: "R4 VERDICT: OK", 400,000 rows, 100% available, about 50 s on CPU.

To submit: zip solution.py on its own, run  sudo check-submission <zip>, and agree with the team before uploading
(only the last upload counts).

Files: solution.py = current version (with the cold-start pick). solution_before_cold_fix.py = the version validated
earlier on the VM, kept only for comparison. Compare both:
  /opt/techarena/venvs/torch/bin/python evaluate_r4.py ~/data/round-4/phase-2-round-4-input solution.py solution_before_cold_fix.py
Note: the replay only scores requests where the user clicked, and almost all of those users have history, so it barely
moves with the cold-start change (66.7% -> 66.8%). The change matters on the real round 4 requests instead.
