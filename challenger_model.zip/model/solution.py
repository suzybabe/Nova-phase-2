"""Choice-model challenger based on the team's attached solution(3).py.

Changes: prefer canonical feedback.jsonl/CSV; train item-appeal weights on expanding
out-of-time Scorer features (no slate's own or future clicks in its AP feature); train
the softmax on every item in each clicked pooled slate; and compare prior-clicked
items against the strongest live global-appeal candidate instead of automatically
preferring any live re-click candidate.

This keeps the same external `scorer.Scorer` API as the attached solution. The scorer
module must be present in the competition runtime / model directory. Experimental:
VM validation is required before replacing the known-good model.
"""
import csv
import json
import os
import sys
import tempfile
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import scorer as nu

W_DEFAULT = np.array([1.103, 1.376, -0.374, -0.271, 0.0], dtype=np.float64)
POOLED_MAX_SLATE = 2.8
DAY = 86400
# The chronological OOF AP blocks use only earlier feedback for each training slate.
AP_FOLDS = [(0.45, 0.65), (0.65, 0.82), (0.82, 1.00)]


def _read_feedback(d):
    """Canonical JSONL takes precedence; long-table encodings are fallbacks only."""
    canonical = d / "feedback.jsonl"
    if canonical.exists():
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="", suffix=".csv") as tmp:
            writer = csv.writer(tmp)
            writer.writerow(["event_id", "user_id", "timestamp", "itemID", "clicked"])
            malformed = missing = bad_click = duplicate_items = 0
            with canonical.open(encoding="utf-8") as src:
                for line in src:
                    try:
                        event = json.loads(line)
                    except Exception:
                        malformed += 1
                        continue
                    if not all(k in event for k in ("event_id", "user_id", "timestamp", "displayed_items")):
                        missing += 1
                        continue
                    slate = [str(item) for item in event["displayed_items"] if item is not None]
                    unique = list(dict.fromkeys(slate))
                    duplicate_items += len(slate) - len(unique)
                    clicked = event.get("clicked_item")
                    clicked = None if clicked is None else str(clicked)
                    if clicked is not None and clicked not in unique:
                        bad_click += 1
                        clicked = None
                    writer.writerows((str(event["event_id"]), str(event["user_id"]),
                                      int(event["timestamp"]), item, int(item == clicked))
                                     for item in unique)
            tmp.flush()
            fb = pd.read_csv(tmp.name, dtype={"event_id": str, "user_id": str, "itemID": str})
        print(f"[nova-choice-v6] canonical JSONL: malformed={malformed}, missing={missing}, "
              f"bad_click={bad_click}, duplicate_items={duplicate_items}", file=sys.stderr, flush=True)
    else:
        pq = d / "feedback_long.parquet"
        csv_path = d / "feedback_long.csv"
        if pq.exists():
            try:
                fb = pd.read_parquet(pq, columns=["event_id", "user_id", "timestamp", "itemID", "clicked"])
            except Exception as exc:
                print("[nova-choice-v6] parquet failed:", exc, file=sys.stderr)
                if not csv_path.exists():
                    raise
                fb = pd.read_csv(csv_path, usecols=["event_id", "user_id", "timestamp", "itemID", "clicked"])
        elif csv_path.exists():
            fb = pd.read_csv(csv_path, usecols=["event_id", "user_id", "timestamp", "itemID", "clicked"])
        else:
            raise FileNotFoundError("feedback.jsonl, feedback_long.parquet, or feedback_long.csv is required")
    for col in ("event_id", "user_id", "itemID"):
        fb[col] = fb[col].astype(str)
    fb["timestamp"] = fb["timestamp"].astype(np.int64)
    fb["clicked"] = fb["clicked"].astype(np.int8)
    return fb.drop_duplicates(["event_id", "itemID"], keep="first").reset_index(drop=True)


def _read(d, name):
    """Prefer CSV inputs; verify this precedence against the competition manifest."""
    csv_path = d / (name + ".csv")
    pq_path = d / (name + ".parquet")
    if csv_path.exists():
        return pd.read_csv(csv_path)
    if pq_path.exists():
        return pd.read_parquet(pq_path)
    raise FileNotFoundError(f"{name}.csv or {name}.parquet is required")


def _features(ap, n, hrs):
    n = np.asarray(n, dtype=np.float64)
    hrs = np.maximum(np.asarray(hrs, dtype=np.float64), 0.0)
    has = (n > 0).astype(np.float64)
    return np.column_stack((np.asarray(ap, dtype=np.float64),
                            np.log1p(n),
                            np.log1p(hrs) * has,
                            (hrs < 12.0).astype(np.float64) * has,
                            has))


def _ap_series(scorer):
    return pd.Series(np.asarray(scorer.ap_all, dtype=np.float64),
                     index=pd.Index(scorer.items).astype(str))


def _fit_scorer(fb, cat):
    if fb.empty or not (fb.clicked == 1).any():
        raise ValueError("Scorer prefix contains no clicked feedback")
    return nu.Scorer(w_knn=0.0, w_reclick=0.0).fit(fb, cat)


def _pooled_clicked_rows(fb):
    day = fb.timestamp // DAY
    ev = fb.groupby("event_id", sort=False).agg(n=("itemID", "size"), t=("timestamp", "first"))
    day_mean = ev.groupby(ev.t // DAY).n.mean()
    pooled_days = set(day_mean[day_mean < POOLED_MAX_SLATE].index)
    P = fb[day.isin(pooled_days)].copy()
    click_sum = P.groupby("event_id", sort=False).clicked.sum()
    valid_ids = click_sum[click_sum == 1].index
    return P[P.event_id.isin(valid_ids)].drop_duplicates(["event_id", "itemID"], keep="first")


def _history_features(candidates, fb, ap):
    """Build prior-click features for rows; each click must strictly precede its slate."""
    cols = ["event_id", "user_id", "timestamp", "itemID", "clicked"]
    m = candidates[cols].copy()
    m["__row"] = np.arange(len(m), dtype=np.int64)
    C = fb.loc[fb.clicked == 1, ["user_id", "itemID", "timestamp"]].copy()
    C = C.sort_values(["user_id", "itemID", "timestamp"], kind="stable")
    C["n"] = C.groupby(["user_id", "itemID"], sort=False).cumcount() + 1
    C = C.rename(columns={"timestamp": "tc"})
    # merge_asof avoids a cartesian join for repeatedly clicked user-item pairs.
    m = pd.merge_asof(m.sort_values(["timestamp", "__row"], kind="stable"),
                      C[["user_id", "itemID", "tc", "n"]].sort_values(["tc", "user_id", "itemID"], kind="stable"),
                      left_on="timestamp", right_on="tc", by=["user_id", "itemID"],
                      direction="backward", allow_exact_matches=False)
    m = m.sort_values("__row", kind="stable").reset_index(drop=True)
    n = m.n.fillna(0).to_numpy(dtype=np.float64)
    last = m["tc"].fillna(0).to_numpy(dtype=np.float64)
    hrs = np.where(n > 0, (m.timestamp.to_numpy(dtype=np.float64) - last) / 3600.0, 0.0)
    apv = ap.reindex(m.itemID.astype(str)).fillna(0.0).to_numpy(dtype=np.float64)
    F = _features(apv, n, hrs)
    return m, F


def _cut_time(event_times, fraction):
    if fraction >= 1.0:
        return float(np.max(event_times)) + 1.0
    return float(np.quantile(event_times, fraction))


def fit_choice(fb, cat):
    """Fit conditional-choice weights using expanding, out-of-time AP features."""
    try:
        P = _pooled_clicked_rows(fb)
        ev_times = fb.drop_duplicates("event_id", keep="first").timestamp.to_numpy(dtype=np.float64)
        if P.event_id.nunique() < 1000:
            raise ValueError(f"only {P.event_id.nunique()} pooled training slates")
        matrices, event_codes, labels = [], [], []
        for lo, hi in AP_FOLDS:
            start, end = _cut_time(ev_times, lo), _cut_time(ev_times, hi)
            block = P[(P.timestamp >= start) & (P.timestamp < end)]
            prefix = fb[fb.timestamp < start]
            if block.event_id.nunique() < 100 or prefix.empty or not (prefix.clicked == 1).any():
                continue
            fold_scorer = _fit_scorer(prefix, cat)
            fold_ap = _ap_series(fold_scorer)
            _, F = _history_features(block, fb, fold_ap)
            e = pd.factorize(block.event_id, sort=False)[0]
            y = block.clicked.to_numpy(dtype=np.float64)
            if len(e) and np.bincount(e, weights=y).min() == 1:
                matrices.append(F.astype(np.float32))
                event_codes.append(e + (max(x.max() + 1 for x in event_codes) if event_codes else 0))
                labels.append(y)
        if not matrices:
            raise ValueError("no usable expanding AP folds")
        F = np.vstack(matrices).astype(np.float64, copy=False)
        y = np.concatenate(labels)
        e = np.concatenate(event_codes).astype(np.int64)
        n_events = int(e.max()) + 1
        if np.bincount(e, weights=y, minlength=n_events).min() != 1:
            raise ValueError("OOF choice training must have exactly one click per slate")

        def loss(w):
            utility = F @ w
            maximum = np.full(n_events, -np.inf, dtype=np.float64)
            np.maximum.at(maximum, e, utility)
            exp_u = np.exp(utility - maximum[e])
            denominator = np.bincount(e, weights=exp_u, minlength=n_events)
            objective = (-(y * (utility - maximum[e])).sum() +
                         np.log(np.maximum(denominator, 1e-300)).sum() + 0.01 * (w @ w))
            grad = (-(F * y[:, None]).sum(0) +
                    (F * (exp_u / denominator[e])[:, None]).sum(0) + 0.02 * w)
            return float(objective), grad

        result = minimize(loss, np.zeros(F.shape[1], dtype=np.float64), jac=True, method="L-BFGS-B")
        W = result.x
        if not np.isfinite(W).all():
            raise ValueError("non-finite weights")
        print(f"[nova-choice-v6] OOF choice fit on {n_events:,} slates; "
              f"converged={result.success}; w={np.round(W, 3)}", file=sys.stderr, flush=True)
        return W
    except Exception as exc:
        print("[nova-choice-v6] OOF choice fit failed; using conservative default weights:", exc,
              file=sys.stderr, flush=True)
        return W_DEFAULT.copy()


def _global_best(rows, cat, ap, w_ap, history):
    vf = cat.valid_from.to_numpy(np.int64)
    vt = cat.valid_to.to_numpy(np.int64)
    citems = cat.itemID.astype(str).to_numpy()
    values = ap.reindex(citems).fillna(0.0).to_numpy(dtype=np.float64)
    order = np.argsort(-(float(w_ap) * values), kind="stable")
    o_items, o_vf, o_vt = citems[order], vf[order], vt[order]
    item_rank = {item: rank for rank, item in enumerate(o_items)}
    user_history = {}
    for user, group in history.groupby("user_id", sort=False):
        ranks = [item_rank[item] for item in group.itemID.astype(str) if item in item_rank]
        user_history[str(user)] = np.asarray(ranks, dtype=np.int64)
    timestamps = rows.timestamp.to_numpy(np.int64)
    users = rows.user_id.astype(str).to_numpy()
    picks = np.empty(len(rows), dtype=object)
    for start in range(0, len(rows), 8192):
        t = timestamps[start:start + 8192, None]
        live = (o_vf[None, :] <= t) & (t < o_vt[None, :])
        if not live.any(axis=1).all():
            raise RuntimeError("a prediction row has no live catalog item")
        first_live = live.argmax(axis=1)
        batch_users = users[start:start + 8192]
        for user in np.unique(batch_users):
            item_ranks = user_history.get(user)
            if item_ranks is not None and len(item_ranks):
                row_idx = np.flatnonzero(batch_users == user)
                live[np.ix_(row_idx, item_ranks)] = False
        has_cold = live.any(axis=1)
        best_rank = first_live
        best_rank[has_cold] = live.argmax(axis=1)[has_cold]
        picks[start:start + 8192] = o_items[best_rank]
    return picks


def predict(data_dir, batch_size=256):
    t0 = time.time()
    d = Path(data_dir)
    fb = _read_feedback(d)
    cat = _read(d, "catalog").astype({"itemID": str}).drop_duplicates("itemID").reset_index(drop=True)
    rows = _read(d, "x_pred").astype({"rowid": str, "user_id": str}).drop_duplicates("rowid").reset_index(drop=True)
    rows["timestamp"] = rows.timestamp.astype(np.int64)
    if len(fb) and len(rows) and int(fb.timestamp.max()) >= int(rows.timestamp.min()):
        raise ValueError("feedback must end before prediction requests; use a chronological prefix for validation")

    # Full-history appeal is appropriate for future prediction; only the choice weights
    # use out-of-time AP features during their training.
    scorer = _fit_scorer(fb, cat)
    ap = _ap_series(scorer)
    W = fit_choice(fb, cat)

    h = (fb.loc[fb.clicked == 1].groupby(["user_id", "itemID"], sort=False)
         .agg(n=("clicked", "size"), last=("timestamp", "max")).reset_index())
    personal = rows[["rowid", "user_id", "timestamp"]].merge(h, on="user_id", how="inner")
    personal = personal[personal["last"] < personal.timestamp].copy()
    vf = cat.set_index("itemID").valid_from
    vt = cat.set_index("itemID").valid_to
    personal["valid_from"] = personal.itemID.map(vf)
    personal["valid_to"] = personal.itemID.map(vt)
    personal = personal[(personal.valid_from <= personal.timestamp) &
                        (personal.timestamp < personal.valid_to)]

    global_items = _global_best(rows, cat, ap, W[0], h)
    global_rows = rows[["rowid", "user_id", "timestamp"]].copy()
    global_rows["itemID"] = global_items
    personal_rows = personal[["rowid", "user_id", "timestamp", "itemID"]]
    candidates = pd.concat([personal_rows, global_rows], ignore_index=True)
    candidates = candidates.drop_duplicates(["rowid", "itemID"], keep="first")
    candidates = candidates.merge(h, on=["user_id", "itemID"], how="left", sort=False)
    n = candidates.n.fillna(0).to_numpy(dtype=np.float64)
    last = candidates["last"].fillna(0).to_numpy(dtype=np.float64)
    hrs = np.where(n > 0, (candidates.timestamp.to_numpy(dtype=np.float64) - last) / 3600.0, 0.0)
    item_ap = ap.reindex(candidates.itemID.astype(str)).fillna(0.0).to_numpy(dtype=np.float64)
    candidates["utility"] = _features(item_ap, n, hrs) @ W
    best = (candidates.sort_values(["rowid", "utility"], ascending=[True, False], kind="stable")
            .drop_duplicates("rowid", keep="first"))
    pick = dict(zip(best.rowid.astype(str), best.itemID.astype(str)))
    result = [pick[str(rowid)] for rowid in rows.rowid]
    print(f"[nova-choice-v6] done {time.time()-t0:.1f}s | candidate rows {len(candidates):,} "
          f"| personalized {len(personal):,}/{len(rows):,} | distinct {len(set(result)):,}",
          file=sys.stderr, flush=True)
    for start in range(0, len(rows), batch_size):
        yield [(str(r), str(p)) for r, p in zip(rows.rowid.iloc[start:start + batch_size],
                                                result[start:start + batch_size])]
